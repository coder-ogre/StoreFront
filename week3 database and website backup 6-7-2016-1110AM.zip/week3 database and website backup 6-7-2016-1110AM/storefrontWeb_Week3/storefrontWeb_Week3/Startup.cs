﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(storefrontWeb_Week3.Startup))]
namespace storefrontWeb_Week3
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
