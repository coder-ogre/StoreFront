﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace storefrontWeb_Week3
{
    public partial class ProductsAdmin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        
        protected void refreshTable(object sender, EventArgs e)
        {
            this.GridView1.DataBind();
        }

        private void Page_Error(object sender, EventArgs e)
        {
            Exception exc = Server.GetLastError();

            // Handle specific exception.
            if (exc is HttpUnhandledException)
            {
                //ErrorMsgTextBox.Text = "An error occurred on this page. Please verify your " +                  
                //"information to resolve the issue."
            }
            // Clear the error from the server.
            //Server.ClearError();
            Response.Redirect("~/ProductsAdmin.aspx");
        }

        protected void goToHomePage(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}