﻿using System.Web.UI;

namespace storefrontWeb_Week3.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}