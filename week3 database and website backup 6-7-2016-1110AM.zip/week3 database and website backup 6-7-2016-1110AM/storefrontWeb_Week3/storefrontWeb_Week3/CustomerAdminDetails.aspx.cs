﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace storefrontWeb_Week3
{
    public partial class CustomerAdminDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void goToCustomersAdminPage(object sender, EventArgs e)
        {
            Response.Redirect("~/CustomersAdmin.aspx");
        }

        protected void refreshAfterUpdate(object sender, EventArgs e)
        {
            this.GridView2.DataBind();
        }

        protected void goToHomePage(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}