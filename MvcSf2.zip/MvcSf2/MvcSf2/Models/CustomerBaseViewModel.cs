﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcSf2.Models;

namespace MvcSf2.Models
{
    public class CustomerBaseViewModel
    {
        /*
        public string UserName
        {
            get
            {

            }
        }
        */

    }
}