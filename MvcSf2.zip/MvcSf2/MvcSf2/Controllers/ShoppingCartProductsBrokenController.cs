﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MvcSf2.Models;

namespace MvcSf2.Controllers
{
    public class ShoppingCartProductsController : Controller
    {
        private MvcSf2DataEntities db = new MvcSf2DataEntities();
        

        // GET: ShoppingCartProducts
        public ActionResult Index()
        {
            //var shoppingCartProductTables = db.ShoppingCartProductTables.Include(s => s.ProductTable).Include(s => s.ShoppingCartTable);
            var scpt = (from s in db.ShoppingCartProductTables select s).FirstOrDefault();
            //var userQuery = (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq).FirstOrDefault();
            //var matchCartToUserQuery = (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault();
            //var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.ShoppingCartID) select cartItemLinq);
            //ShoppingCartProductTable scpt = new ShoppingCartProductTable();
            //return View(matchCartItemToCart.ToList());
            return View(scpt);
        }

        /*public ActionResult UpdateQuantity(int id, int quant)
        {
            var shoppingCartProductTables = db.ShoppingCartProductTables.Include(s => s.ProductTable).Include(s => s.ShoppingCartTable);
            var userQuery = (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq).FirstOrDefault();
            var matchCartToUserQuery = (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault();
            var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.ShoppingCartID && c.ProductID == id) select cartItemLinq).FirstOrDefault();
            ShoppingCartProductTable cartItem = matchCartItemToCart;
            cartItem.Quantity = quant;
            db.SaveChanges();

            return View(shoppingCartProductTables.ToList());
        }*/

        //[HttpPost]
        public ActionResult AddToCart5(int id)
        {
            //var userQuery = from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq.UserID;
            //var matchCartToUserQuery = from shoppingCartLinq in db.ShoppingCartTables join userLinqLinq in userQuery on shoppingCartLinq.UserID equals userLinqLinq select shoppingCartLinq.ShoppingCartID;
            ///////////////////////////var matchProductToCart = from shoppingCartProductLinq in odb.ShoppingCartProductTables join shoppingCartLinqLinq in matchCartToUserQuery on shoppingCartProductLinq.ShoppingCartID equals shoppingCartLinqLinq select shoppingCartProductLinq.ShoppingCartProductID;

            //var getPriceQuery = from priceLinq in db.ProductTables where priceLinq.ProductID == id select priceLinq.Price;
            //var getImageQuery = from imageLinq in db.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile;
            //var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.Single() && c.ProductID == id) select cartItemLinq).FirstOrDefault();
            //Session["userId2"] = userNameToIDQuery;

            var userQuery = (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq).FirstOrDefault();
            var matchCartToUserQuery = (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault();
            //var matchProductToCart = from shoppingCartProductLinq in odb.ShoppingCartProductTables join shoppingCartLinqLinq in matchCartToUserQuery on shoppingCartProductLinq.ShoppingCartID equals shoppingCartLinqLinq select shoppingCartProductLinq.ShoppingCartProductID;

            var getPriceQuery = from priceLinq in db.ProductTables where priceLinq.ProductID == id select priceLinq.Price;
            var getImageQuery = from imageLinq in db.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile;
            int testCounter = (from imageLinq in db.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile).Count();
            var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.ShoppingCartID && c.ProductID == id) select cartItemLinq).FirstOrDefault();


            if (!(matchCartItemToCart == null))
            {
                //var cartItemToUpdate = from citu in db.ShoppingCartProductTables.Where(c => c.ShoppingCartProductID == matchCartItemToCart.ShoppingCartProductID) select citu;
                matchCartItemToCart.Quantity = matchCartItemToCart.Quantity + 1;
                db.Entry(matchCartItemToCart).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Search");
            }
            else
            {
                var scpt = new ShoppingCartProductTable
                {
                    ShoppingCartID = matchCartToUserQuery.ShoppingCartID,
                    ProductID = id,
                    Quantity = 1,
                    Price = getPriceQuery.Single()//(currentProduct.Price == null) ? 0 : currentProduct.Price
                };
                db.ShoppingCartProductTables.Add(scpt);
                db.SaveChanges();
                return RedirectToAction("Index", "Search");
            }

            

            
        }

        // GET: ShoppingCartProducts/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            if (shoppingCartProductTable == null)
            {
                return HttpNotFound();
            }
            return View(shoppingCartProductTable);
        }

        // GET: ShoppingCartProducts/Create
        public ActionResult Create()
        {
            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName");
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy");
            return View();
        }

        // POST: ShoppingCartProducts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ShoppingCartProductID,ShoppingCartID,ProductID,Quantity,Price,CreatedBy,DateModified,ModifiedBy")] ShoppingCartProductTable shoppingCartProductTable)
        {
            if (ModelState.IsValid)
            {
                db.ShoppingCartProductTables.Add(shoppingCartProductTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName", shoppingCartProductTable.ProductID);
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy", shoppingCartProductTable.ShoppingCartID);
            return View(shoppingCartProductTable);
        }

        // GET: ShoppingCartProducts/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            if (shoppingCartProductTable == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName", shoppingCartProductTable.ProductID);
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy", shoppingCartProductTable.ShoppingCartID);
            return View(shoppingCartProductTable);
        }

        // POST: ShoppingCartProducts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ShoppingCartProductID,ShoppingCartID,ProductID,Quantity,Price,CreatedBy,DateModified,ModifiedBy")] ShoppingCartProductTable shoppingCartProductTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(shoppingCartProductTable).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName", shoppingCartProductTable.ProductID);
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy", shoppingCartProductTable.ShoppingCartID);
            return View(shoppingCartProductTable);
        }

        // GET: ShoppingCartProducts/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            if (shoppingCartProductTable == null)
            {
                return HttpNotFound();
            }
            return View(shoppingCartProductTable);
        }

        // POST: ShoppingCartProducts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            db.ShoppingCartProductTables.Remove(shoppingCartProductTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
