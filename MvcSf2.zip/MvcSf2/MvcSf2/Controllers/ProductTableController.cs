﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MvcSf2.Models;
using System.Data.SqlClient;

namespace MvcSf2.Controllers
{
    public class ProductTableController : Controller
    {
        private MvcSf2DataEntities db = new MvcSf2DataEntities();
        //private SearchViewModel svm = new SearchViewModel();
        private string currentEmailAddress = System.Web.HttpContext.Current.User.Identity.Name;

        // GET: ProductTables
        public ActionResult Index(string searchString)//<- change parameter to id with extra mod. #2 to use /Index/searchValue instead of query strings
        {
            //#2  string searchString = id;

            //return Content("HELLO, AND WELCOME TO THE SEARCH PAGE.");
            //return View(db.ProductTables.ToList());
            var productsForSearch = from p in db.ProductTables select p;

            if (!String.IsNullOrEmpty(searchString))
            {
                productsForSearch = productsForSearch.Where(s => s.ProductName.Contains(searchString));
                return View(productsForSearch);
            }
            else
            {
                return View("IndexNullResult");
            }
            

            //return View(productsForSearch);
        }

        // GET: ProductTables/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductTable productTable = db.ProductTables.Find(id);
            if (productTable == null)
            {
                return HttpNotFound();
            }
            return View(productTable);
        }

        // GET: ProductTables/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ProductTables/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProductID,ProductName,ProductDescription,IsPublished,Quantity,Price,ImageFile,DateCreated,CreatedBy,DateModified,ModifiedBy")] ProductTable productTable)
        {
            if (ModelState.IsValid)
            {
                db.ProductTables.Add(productTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(productTable);
        }

        // GET: ProductTables/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductTable productTable = db.ProductTables.Find(id);
            if (productTable == null)
            {
                return HttpNotFound();
            }
            return View(productTable);
        }

        // POST: ProductTables/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProductID,ProductName,ProductDescription,IsPublished,Quantity,Price,ImageFile,DateCreated,CreatedBy,DateModified,ModifiedBy")] ProductTable productTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(productTable).State = EntityState.Modified;
                db.SaveChanges();
                
                return RedirectToAction("Index");
            }
            return View(productTable);
        }

        // GET: ProductTables/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductTable productTable = db.ProductTables.Find(id);
            if (productTable == null)
            {
                return HttpNotFound();
            }
            return View(productTable);
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddToShoppingCart([Bind(Include = "ProductID, ProductName, Price")] ProductTable productTable)
        {
           /* exec sp_executesql N'INSERT [dbo].[Student]([StudentName], [StandardId])'
                 ,N'VALUES(@0, NULL)
                 ,N'SELECT[StudentID], [RowVersion]'
                 ,N'FROM[dbo].[Student]'
                 ,N'WHERE @@ROWCOUNT > 0 AND[StudentID] = scope_identity(),@0='Bill';*/

            return View(productTable);
        }

        /*         //cannot get this action to work
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddToShoppingCart([Bind(Include = "ProductID,ProductName,ProductDescription,IsPublished,Quantity,Price,ImageFile,DateCreated,CreatedBy,DateModified,ModifiedBy")] ProductTable productTable)
        {
            if (ModelState.IsValid)
            {
                db.ProductTables.Add(productTable);
                db.SaveChanges();
                return RedirectToAction("Index");


                //var userInstance = new UserTable();
                var scInstance = new ShoppingCartTable();
                //var pInstance = new ProductTable();
                //var userInstance = from somePerson in UserTable where 
                //var shoppingCartProductInstance = from cart in db.ShoppingCartProductTables where cart.ShoppingCartID = (from cart2 in db.ShoppingCartTables where cart2.UserID = (from somePerson in db.UserTables where string.Equals(somePerson.EmailAddress, currentEmailAddress) select somePerson.UserID) select cart2.ShoppingCartID) select cart;
                var shoppingCartProductInstance = from cart in db.ShoppingCartProductTables where cart.ShoppingCartID == (from cart2 in db.ShoppingCartTables where cart2.UserID == 2 select cart2) select cart;
                var userInstance = from somePerson in UserTable where String.Equals(somePerson.EmailAddress, System.Web.HttpContext.Current.User.Identity.Name) select somePerson;
                IEnumerable<ShoppingCartTable> shoppingCartInstance = from shoppa in ShoppingCartTable where (shoppingCartInstance.ShoppingCartID == 1) select shoppa;

            }

            return View(productTable);
        }*/

        public ActionResult AddToCart2(int? id)
        {
            //[HttpPost]
            /*
             * http://stackoverflow.com/questions/30014453/solved-using-sql-statement-to-add-data-to-ef-db
             * */
            /*
            < script >
             $(document).ready(function() {  
                //function will be called on button click having id btnsave
                $("#btnSave").click(function() {  
            $.ajax(
            {
                    type: "POST", //HTTP POST Method  
                url: "Home/AddEmployee", // Controller/View   
                data:
                        { //Passing data  
                        Name: $("#txtName").val(), //Reading text box values using Jquery   
                    City: $("#txtAddress").val(),  
                    Address: $("#txtcity").val()
                }

                    });

                });
            });


            </ script >*/

            //db.ShoppingCartProductTables.Add(new ShoppingCartProductTables);

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            ProductTable product = db.ProductTables.Find(id);

            string constr = @"Data Source = 1JN2FZ1\SQLEXPRESS; Initial Catalog = StoreFront; Integrated Security = True; MultipleActiveResultSets = True; Application Name = EntityFramework";

            using (SqlConnection con = new SqlConnection(constr))
            {

                //using (SqlCommand cmd = new SqlCommand("insert into ShoppingCartProduct values(1, @ProductID, 1, @ItemPrice, CURRENT_TIMESTAMP, CURRENT_USER, CURRENT_TIMESTAMP, CURRENT_USER) "))
                using (SqlCommand cmd = new SqlCommand("insert into ShoppingCartProduct values(1, @ProductID, 1, @ItemPrice, CURRENT_TIMESTAMP, CURRENT_USER, CURRENT_TIMESTAMP, CURRENT_USER) "))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@ProductID", product.ProductID);
                    cmd.Parameters.AddWithValue("@ItemPrice", product.Price);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }

            }

            return View(product);


        }



        // POST: ProductTables/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ProductTable productTable = db.ProductTables.Find(id);
            db.ProductTables.Remove(productTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
