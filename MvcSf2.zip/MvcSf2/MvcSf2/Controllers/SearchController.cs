﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MvcSf2.Models;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;

namespace MvcSf2.Controllers
{
    public class SearchController : Controller
    {
        //private SearchContext db = new SearchContext();
        private MvcSf2DataEntities odb = new MvcSf2DataEntities();
       
        // GET: Search
        public ActionResult Index(string searchString)
        {
            //return View(db.SearchResultViewModels.ToList());

            var productsForSearch = from p in odb.ProductTables select p;

            if (!String.IsNullOrEmpty(searchString))
            {
                productsForSearch = productsForSearch.Where(s => s.ProductName.Contains(searchString));
                return View(productsForSearch);
            }
            else
            {
                return View("IndexNullResult");
            }
        }

        // GET: Search/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductTable searchResultViewModel = odb.ProductTables.Find(id);
            if (searchResultViewModel == null)
            {
                return HttpNotFound();
            }
            return View(searchResultViewModel);
        }

        /* GET: Search/Create
        public ActionResult Create()
        {
            db.SearchResultViewModels.Add(this);
            db.SaveChanges();
            return View();
        }*/

        // POST: Search/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost, ActionName("AddToCart")]
        [ValidateAntiForgeryToken]
        //public ActionResult AddToCart([Bind(Include = "ID,Name,Price,ImageFile")] SearchResultViewModel searchResultViewModel)
        public ActionResult AddToCart( ShoppingCartProductTable scpt)
        {/*
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SearchResultViewModel searchResultViewModel = db.SearchResultViewModels.Find(id);
            if (searchResultViewModel == null)
            {
                return HttpNotFound();
            }
            return View(searchResultViewModel);*/


            //string rawId = "";
            //return Content("Hello");
            string rawId = Request.QueryString["ID"];
            //return Content("HEY, the value of rawID is ",  rawId);
            if (ModelState.IsValid)
            {
                //db.SearchResultViewModels.Add(searchResultViewModel);
                //db.SaveChanges();
                //return RedirectToAction("Index");

                //difficulty with this.  Using http://www.dotnetperls.com/join for help.
                //var userInstance = new UserTable();
                //var scInstance = new ShoppingCartTable();
                //var pInstance = new ProductTable();
                //var userInstance = from somePerson in UserTable where 
                //var shoppingCartProductInstance = from cart in db.ShoppingCartProductTables where cart.ShoppingCartID = (from cart2 in db.ShoppingCartTables where cart2.UserID = (from somePerson in db.UserTables where string.Equals(somePerson.EmailAddress, currentEmailAddress) select somePerson.UserID) select cart2.ShoppingCartID) select cart;
                //var linq1query2 = from linq1 in odb.UserTables where String.Equals(linq1.UserName, System.Web.HttpContext.Current.User.Identity.Name) select linq1.UserID;
                //var linq2query = from linq2 in odb.ShoppingCartProductTables where linq2.ShoppingCartID = linq1query.ShoppingCartID select linq2;
                //var linq1query = from linq2 in odb.ShoppingCartTables where linq2.UserID = (from linq1 in odb.UserTables where String.Equals(linq1.UserName, System.Web.HttpContext.Current.User.Identity.Name)  select linq1.UserID);
                //var linq2query3 = from linq2 in odb.ShoppingCartTables join linq1 in odb.UserTables where String.Equals(linq1.EmailAddress, System.Web.HttpContext.Current.User.Identity.Name) select linq2.ShoppingCartID;
                //var linq2query3 = from linq2 in odb.ShoppingCartTables join linq1 in odb.UserTables on String.Equals(linq1.EmailAddress, System.Web.HttpContext.Current.User.Identity.Name) select linq2.ShoppingCartID;
                //var shoppingCartProductInstance = from cart in odb.ShoppingCartProductTables where cart.ShoppingCartID == (from cart2 in odb.ShoppingCartTables where cart2.UserID == 2 select cart2) select cart;
                //var userInstance = from somePerson in UserTable where String.Equals(somePerson.EmailAddress, System.Web.HttpContext.Current.User.Identity.Name) select somePerson;
                //IEnumerable<ShoppingCartTable> shoppingCartInstance = from shoppa in ShoppingCartTable where (shoppingCartInstance.ShoppingCartID == 1) select shoppa;
                //var linquery = from userLinq in odb.UserTables join shoppingCartLinq in odb.ShoppingCartTables on String.Equals(userLinq.EmailAddress, System.Web.HttpContext.Current.User.Identity.Name)/*join searchLinq in db.SearchResultViewModels */ select new { shoppingCartLinq.ShoppingCartID };


                //var linquery = from shoppingCartLinq in odb.ShoppingCartTables join userLinqLinq in from userLinq in odb.UserTables.Where(userLinq => String.Equals(userLinq.EmailAddress, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq.UserID on shoppingCartLinq.ShoppingCartID ==  /*join searchLinq in db.SearchResultViewModels */ select  shoppingCartLinq.ShoppingCartID ;
                var useEmailAddressQuery = from userLinq in odb.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq.UserID;
                var matchCartToEmailAddressQuery = from shoppingCartLinq in odb.ShoppingCartTables join userLinqLinq in useEmailAddressQuery on shoppingCartLinq.UserID equals userLinqLinq select shoppingCartLinq.ShoppingCartID;
                var matchProductToCart = from shoppingCartProductLinq in odb.ShoppingCartProductTables join shoppingCartLinqLinq in matchCartToEmailAddressQuery on shoppingCartProductLinq.ShoppingCartID equals shoppingCartLinqLinq select shoppingCartProductLinq.ShoppingCartProductID;

                var getPriceQuery = from priceLinq in odb.ProductTables where priceLinq.ProductID == Int32.Parse(rawId) select priceLinq.Price;
                var getImageQuery = from imageLinq in odb.ProductTables where imageLinq.ProductID == Int32.Parse(rawId) select imageLinq.ImageFile;

                if (!matchProductToCart.Any())
                {
                    scpt = new ShoppingCartProductTable
                    {
                        //ShoppingCartProductID = Guid.NewGuid(),
                        ShoppingCartProductID = 79,
                        ShoppingCartID = matchProductToCart.Single(),
                        ProductID = Int32.Parse(rawId),
                        Quantity = 1,
                        Price = getPriceQuery.Single()
                    };
                    odb.ShoppingCartProductTables.Add(scpt);
                    odb.SaveChanges();
                }
                else
                {
                    scpt = new ShoppingCartProductTable
                    {
                        //ShoppingCartProductID = Guid.NewGuid(),
                        ShoppingCartProductID = 78,
                        ShoppingCartID = matchProductToCart.Single(),
                        ProductID = Int32.Parse(rawId),
                        Quantity = 1,
                        Price = getPriceQuery.Single()
                    };
                    odb.ShoppingCartProductTables.Add(scpt);
                    odb.SaveChanges();
                }



                /*if (!useEmailAddressQuery.Any())
                {
                    odb.UserTables.Add()  <- adding the user to the database with the email address should not be done here.  hardcode for now.
                }*/
                //odb.ShoppingCartProductTables.Add();

                return RedirectToAction("Index");
                //return View(searchResultViewModel);
            }

            //return View(searchResultViewModel);
            return RedirectToAction("Index");
        }



        // POST: Search/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult AddToCart([Bind(Include = "ID,Name,Price,ImageFile")] SearchResultViewModel searchResultViewModel)
        public ActionResult AddToCart3(int id)
        {
            //if (ModelState.IsValid)
            //{
            //var useEmailAddressQuery = from userLinq in odb.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq.UserID;
            //var matchCartToEmailAddressQuery = from shoppingCartLinq in odb.ShoppingCartTables join userLinqLinq in useEmailAddressQuery on shoppingCartLinq.UserID equals userLinqLinq select shoppingCartLinq.ShoppingCartID;
            //var matchProductToCart = from shoppingCartProductLinq in odb.ShoppingCartProductTables join shoppingCartLinqLinq in matchCartToEmailAddressQuery on shoppingCartProductLinq.ShoppingCartID equals shoppingCartLinqLinq select shoppingCartProductLinq.ShoppingCartProductID;

            //var getPriceQuery = from priceLinq in db.SearchResultViewModels where priceLinq.ID == id select priceLinq.Price;
            //var getImageQuery = from imageLinq in db.SearchResultViewModels where imageLinq.ID == id select imageLinq.ImageFile;
            var currentUser = odb.UserTables.SingleOrDefault
                (
                    //u => u.UserName == System.Web.HttpContext.Current.User.Identity.Name
                    u => u.UserName == User.Identity.GetUserName()
                );
            var currentShoppingCart = odb.ShoppingCartTables.Single(
                s => s.UserID == currentUser.UserID);
            var currentProduct = odb.ProductTables.Single(
                p => p.ProductID == id);
            /*var cartItem = odb.ShoppingCartProductTables.SingleOrDefault(
                c => c.ShoppingCartID == currentShoppingCart.ShoppingCartID
                && c.ProductID == id);*/
            //cartItem = new ShoppingCartProductTable
            //{
            //    cartItem.ShoppingCartID = 1
            //};
            try
            {
                var scpt = new ShoppingCartProductTable
                {
                    ShoppingCartID = currentShoppingCart.ShoppingCartID,
                    ProductID = id,
                    Quantity = 1,
                    Price = currentProduct.Price//(currentProduct.Price == null) ? 0 : currentProduct.Price
                };

                odb.ShoppingCartProductTables.Add(scpt);
                odb.SaveChanges();
            }
            catch
            {

            }



            /*
                if (!matchProductToCart.Any())
                {
                    var scpt = new ShoppingCartProductTable
                    {
                        //ShoppingCartProductID = Guid.NewGuid(),
                        ShoppingCartProductID = 79,
                        ShoppingCartID = matchProductToCart.Single(),
                        ProductID = id,
                        Quantity = 1,
                        Price = getPriceQuery.Single()
                    };
                    odb.ShoppingCartProductTables.Add(scpt);
                    odb.SaveChanges();
                }
                else
                {
                    var scpt = new ShoppingCartProductTable
                    {
                        //ShoppingCartProductID = Guid.NewGuid(),
                        ShoppingCartProductID = 78,
                        ShoppingCartID = matchProductToCart.Single(),
                        ProductID = id,
                        Quantity = 1,
                        Price = getPriceQuery.Single()
                    };
                    odb.ShoppingCartProductTables.Add(scpt);
                    odb.SaveChanges();
                }*/
            //}
            return View("Index");
        }

        public string AddToCart4(int id/*,int userId*/)
        {
            //var query = odb.UserTables.Where(x => x.UserID == id)
            //var userQuery = from userLinq in odb.UserTables.Where(userLinq => String.Equals(userLinq.UserName, User.Identity.GetUserName())) select userLinq.UserName;
            var userQuery = from userLinq in odb.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq.UserID;
            var matchCartToUserQuery = from shoppingCartLinq in odb.ShoppingCartTables join userLinqLinq in userQuery on shoppingCartLinq.UserID equals userLinqLinq select shoppingCartLinq.ShoppingCartID;
            //var matchProductToCart = from shoppingCartProductLinq in odb.ShoppingCartProductTables join shoppingCartLinqLinq in matchCartToUserQuery on shoppingCartProductLinq.ShoppingCartID equals shoppingCartLinqLinq select shoppingCartProductLinq.ShoppingCartProductID;

            var getPriceQuery = from priceLinq in odb.ProductTables where priceLinq.ProductID == id select priceLinq.Price;
            var getImageQuery = from imageLinq in odb.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile;
            //Session["userId2"] = userNameToIDQuery;
            /*
            try
            {
                var currentUser = odb.UserTables.SingleOrDefault
                (
                    //u => u.UserName == System.Web.HttpContext.Current.User.Identity.Name
                    //u => u.UserName == User.Identity.GetUserName()
                    u => u.UserID == (int)Session["userId2"] //String.Equals(u.UserName, User.Identity.GetUserName())
                );

                return "" + currentUser.UserName;
            }
            catch
            {
                return "SOmething bad happened.";
            }*/
            /*
            var currentUser2 = odb.UserTables.SingleOrDefault
                (
                    //u => u.UserName == System.Web.HttpContext.Current.User.Identity.Name
                    //u => u.UserName == User.Identity.GetUserName()
                    u => u.UserID == (int)Session["userId2"] //String.Equals(u.UserName, User.Identity.GetUserName())
                );*/
            //var currentUser = from user3 in odb.UserTables.Where(user3 => String.Equals(user3.UserName, User.Identity))

            return "UserID is" + userQuery.Single() + "\r\nShoppingCartID is " + matchCartToUserQuery.Single() + "\r\nProductID is " + id + "\r\nprice is " + getPriceQuery.Single() + "\r\nimageLink is " + getImageQuery.Single();
            /*
            try
            {
                var currentUser = odb.UserTables.SingleOrDefault
                (
                    //u => u.UserName == System.Web.HttpContext.Current.User.Identity.Name
                    u => u.UserName == User.Identity.GetUserName()
                );
                var currentShoppingCart = odb.ShoppingCartTables.Single(
                    s => s.UserID == currentUser.UserID);
                var currentProduct = odb.ProductTables.Single(
                    p => p.ProductID == id);

                var scpt = new ShoppingCartProductTable
                {
                    ShoppingCartID = currentShoppingCart.ShoppingCartID,
                    ProductID = id,
                    Quantity = 1,
                    Price = currentProduct.Price//(currentProduct.Price == null) ? 0 : currentProduct.Price
                };

                odb.ShoppingCartProductTables.Add(scpt);
                odb.SaveChanges();

                return "Your username is '" + System.Web.HttpContext.Current.User.Identity.Name + "' or '" + User.Identity.GetUserName() + "'\n" +
                "Your current shoppingCartID is " + currentShoppingCart.ShoppingCartID + "\n" +
                "Your current Product is " + currentProduct.ProductID;
            }
            catch
            {
                return "SOmething bad happened.";
            }*/
        }


       


        /*
        public ActionResult AddToCartConfirmation(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SearchResultViewModel searchResultViewModel = db.SearchResultViewModels.Find(id);
            if (searchResultViewModel == null)
            {
                return HttpNotFound();
            }
            return View(searchResultViewModel);
        }*/

        // GET: Search/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductTable searchResultViewModel = odb.ProductTables.Find(id);
            if (searchResultViewModel == null)
            {
                return HttpNotFound();
            }
            return View(searchResultViewModel);
        }

        // POST: Search/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name,Price,ImageFile")] SearchResultViewModel searchResultViewModel)
        {
            if (ModelState.IsValid)
            {
                odb.Entry(searchResultViewModel).State = EntityState.Modified;
                odb.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(searchResultViewModel);
        }

        // GET: Search/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductTable searchResultViewModel = odb.ProductTables.Find(id);
            if (searchResultViewModel == null)
            {
                return HttpNotFound();
            }
            return View(searchResultViewModel);
        }

        // POST: Search/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ProductTable searchResultViewModel = odb.ProductTables.Find(id);
            odb.ProductTables.Remove(searchResultViewModel);
            odb.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                odb.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

//publiic ActionResult AddToCart(int? id, int? cartid, int? productid)
//{
//    if db.S
//    ShoppingCartProductTable newiNSTANCE = new ShoppingCartProductTable()
//}
