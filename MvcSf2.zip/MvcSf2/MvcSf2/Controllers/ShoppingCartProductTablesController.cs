﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MvcSf2.Models;

namespace MvcSf2.Controllers
{
    public class ShoppingCartProductTablesController : Controller
    {
        private MvcSf2DataEntities db = new MvcSf2DataEntities();

        // GET: ShoppingCartProductTables
        public ActionResult Index()
        {
            //var shoppingCartProductTables = db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq.UserID).Single()).Include(s => s.ProductTable).Include(s => s.ShoppingCartTable);
            ViewBag.Price = getPrice();
            //var shoppingCartProductTables = from shoppingCart in (  db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault()) select shoppingCart );
            return View(getCartItems());
        }

        public ActionResult Checkout()
        {
            var userQuery = (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq).FirstOrDefault();
            var matchCartToUserQuery = (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault();
            var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.ShoppingCartID) select cartItemLinq).ToList();

            

            foreach (var item in matchCartItemToCart)
            {
                var productTemp = (from qualityQualifier in db.ProductTables.Where(QQ => QQ.ProductID == item.ProductID) select qualityQualifier).FirstOrDefault();
                productTemp.Quantity = productTemp.Quantity - item.Quantity;
                if(productTemp.Quantity < 1)
                {
                    db.ProductTables.Remove(productTemp);
                }
                db.ShoppingCartProductTables.Remove(item);
                db.SaveChanges();
            }
            return RedirectToAction("Index", "Home");
        }

        public ActionResult AddToCart5(int id)
        {
            var userQuery = (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq).FirstOrDefault();
            var matchCartToUserQuery = (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault();
            
            var getPriceQuery = from priceLinq in db.ProductTables where priceLinq.ProductID == id select priceLinq.Price;
            var getImageQuery = from imageLinq in db.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile;
            int testCounter = (from imageLinq in db.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile).Count();
            var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.ShoppingCartID && c.ProductID == id) select cartItemLinq).FirstOrDefault();


            if (!(matchCartItemToCart == null))
            {
                //matchCartItemToCart.Price = (getPriceQuery.Single() == null)? (decimal)(3.01):(getPriceQuery.Single() * (matchCartItemToCart.Quantity + 1));
                matchCartItemToCart.Quantity = matchCartItemToCart.Quantity + 1;

                var productTemp = (from qualityQualifier in db.ProductTables.Where(QQ => QQ.ProductID == id) select qualityQualifier).FirstOrDefault();
                if (matchCartItemToCart.Quantity > (productTemp.Quantity))
                {
                    matchCartItemToCart.Quantity = productTemp.Quantity;
                }

                matchCartItemToCart.Price = productTemp.Quantity * productTemp.Price;

                db.SaveChanges();

                db.Entry(matchCartItemToCart).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "ProductTable");
            }
            else
            {
                var scpt = new ShoppingCartProductTable
                {
                    ShoppingCartID = matchCartToUserQuery.ShoppingCartID,
                    ProductID = id,
                    Quantity = 1,
                    Price = (getPriceQuery.Single().Equals(null))?(decimal)(1.01):getPriceQuery.Single()
                };
                db.ShoppingCartProductTables.Add(scpt);
                db.SaveChanges();
                return RedirectToAction("Index", "ProductTable");
            }
        }

        // GET: ShoppingCartProductTables/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            if (shoppingCartProductTable == null)
            {
                return HttpNotFound();
            }
            return View(shoppingCartProductTable);
        }

        // GET: ShoppingCartProductTables/Create
        public ActionResult Create()
        {
            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName");
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy");
            return View();
        }

        // POST: ShoppingCartProductTables/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ShoppingCartProductID,ShoppingCartID,ProductID,Quantity,Price,CreatedBy,DateModified,ModifiedBy")] ShoppingCartProductTable shoppingCartProductTable)
        {
            if (ModelState.IsValid)
            {
                db.ShoppingCartProductTables.Add(shoppingCartProductTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName", shoppingCartProductTable.ProductID);
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy", shoppingCartProductTable.ShoppingCartID);
            return View(shoppingCartProductTable);
        }

        // GET: ShoppingCartProductTables/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            if (shoppingCartProductTable == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName", shoppingCartProductTable.ProductID);
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy", shoppingCartProductTable.ShoppingCartID);
            return View(shoppingCartProductTable);
        }

        // POST: ShoppingCartProductTables/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ShoppingCartProductID,ShoppingCartID,ProductID,Quantity,Price,CreatedBy,DateModified,ModifiedBy")] ShoppingCartProductTable shoppingCartProductTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(shoppingCartProductTable).State = EntityState.Modified;
                
                var productTemp = (from qualityQualifier in db.ProductTables.Where(QQ => QQ.ProductID == shoppingCartProductTable.ProductID) select qualityQualifier).FirstOrDefault();

                if (shoppingCartProductTable.Quantity > (productTemp.Quantity))
                {
                    shoppingCartProductTable.Quantity = productTemp.Quantity;
                }

                shoppingCartProductTable.Price = productTemp.Quantity * productTemp.Price;
                
                db.SaveChanges();
               
                return RedirectToAction("Index");
            }

            ViewBag.ProductID = new SelectList(db.ProductTables, "ProductID", "ProductName", shoppingCartProductTable.ProductID);
            ViewBag.ShoppingCartID = new SelectList(db.ShoppingCartTables, "ShoppingCartID", "CreatedBy", shoppingCartProductTable.ShoppingCartID);
            return View(shoppingCartProductTable);
        }

        // GET: ShoppingCartProductTables/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            if (shoppingCartProductTable == null)
            {
                return HttpNotFound();
            }
            return View(shoppingCartProductTable);
        }

        // POST: ShoppingCartProductTables/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ShoppingCartProductTable shoppingCartProductTable = db.ShoppingCartProductTables.Find(id);
            db.ShoppingCartProductTables.Remove(shoppingCartProductTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


        //////helpers //////////////////

        public List<ShoppingCartProductTable> getCartItems()
        {
            var userQuery = (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq).FirstOrDefault();
            var matchCartToUserQuery = (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault();

            //var getPriceQuery = from priceLinq in db.ProductTables where priceLinq.ProductID == id select priceLinq.Price;
            //var getImageQuery = from imageLinq in db.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile;
            //int testCounter = (from imageLinq in db.ProductTables where imageLinq.ProductID == id select imageLinq.ImageFile).Count();
            var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.ShoppingCartID) select cartItemLinq).ToList();
            return matchCartItemToCart;
        }

        public double getPrice()
        {
            var userQuery = (from userLinq in db.UserTables.Where(userLinq => String.Equals(userLinq.UserName, System.Web.HttpContext.Current.User.Identity.Name)) select userLinq).FirstOrDefault();
            var matchCartToUserQuery = (from shoppingCartLinq in db.ShoppingCartTables.Where(s => s.UserID == userQuery.UserID) select shoppingCartLinq).FirstOrDefault();
            //var getPrice = (from price in db.ProductTables.Where(p => p.ProductID == ))
            //var getPriceQuery = from priceLinq in db.ProductTables where priceLinq.ProductID == shoppingCartProductTable.ProductID select priceLinq.Price;
            double totalPrice = 0;
            var theProduct = (from item in db.ShoppingCartProductTables.Where(t => t.ShoppingCartID == matchCartToUserQuery.ShoppingCartID) select item);
            foreach(var item in theProduct)
            {
                totalPrice += (double)(from price in db.ProductTables.Where(u => u.ProductID == item.ProductID) select price.Price).FirstOrDefault()*(double)item.Quantity;
            }

            //var matchCartItemToCart = (from cartItemLinq in db.ShoppingCartProductTables.Where(c => c.ShoppingCartID == matchCartToUserQuery.ShoppingCartID && c.ProductID == shoppingCartProductTable.ProductID) select cartItemLinq).FirstOrDefault();
            //matchCartItemToCart.Price = getPriceQuery.Single() * matchCartItemToCart.Quantity;


            return totalPrice;
        }
    }
}

